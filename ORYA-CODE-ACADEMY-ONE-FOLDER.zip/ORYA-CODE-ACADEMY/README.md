# ORYA CODE ACADEMY — Android Native Project

**LEARN · CODE · BUILD**  
Premium black & gold learning app. Native Android/Kotlin, designed to keep course material locally available without internet.

## What this starter contains
- Native Android Studio project (Kotlin), not a website/PWA.
- Local curriculum content bundled in `Curriculum.kt`.
- 8 learning tracks: computer/web basics, HTML5, CSS3 + responsive design/UI/UX, JavaScript, Git/GitHub, Node.js/Express, SQL/database, React + capstone.
- Lessons have explanations, code examples, practical tasks, estimated time and a short answer-check quiz.
- Progress for completed lessons stored locally using SharedPreferences.
- Class schedule with start time, duration and computed end time.
- Android notification alarm; requests notification permission. Exact alarm permission may need to be enabled by the user in system settings.
- Daily motivation lines.

## Build APK
1. Install Android Studio on a computer.
2. Open this folder as an existing Android Studio project.
3. Allow Gradle sync (first setup usually needs internet to fetch Android Gradle Plugin/Kotlin dependencies).
4. Choose **Build > Build APK(s)**.
5. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

After building, the app's bundled lessons and core UI run offline. This ZIP is source code, not a prebuilt APK.

## Important limits in v1.0
This is a functional native-app foundation, not yet the exhaustive “zero to expert” curriculum. The bundled material is an introductory set of structured lessons, not every advanced topic or full worked project source. The quiz currently checks short written answers against sample answers; a future upgrade should add multiple-choice exams, graded checkpoints, full project files, richer Dari explanations, code runner integration where feasible, and a dedicated adaptive-icon asset. Alarm delivery depends on Android notification and exact-alarm permissions and manufacturer battery settings. The alarm is scheduled locally; it does not need internet.

## Brand
- App label: ORYA CODE ACADEMY
- Tagline: LEARN · CODE · BUILD
- Black: `#080808`
- Gold: `#D4AF37`

## Build APK through GitHub Actions (no Android Studio on your PC)
1. Create a GitHub repository and upload **the contents of this project folder** (including `.github/workflows/build-apk.yml`) to its `main` branch.
2. Open the repository's **Actions** tab and choose **Build ORYA CODE ACADEMY APK**.
3. Press **Run workflow**. Wait until the run finishes successfully.
4. Open that completed run and download the artifact named **ORYA-CODE-ACADEMY-debug-apk**. Extract it to get `app-debug.apk`, then transfer/install it on your Android phone.

GitHub Actions requires internet on GitHub's build servers. Your own computer does not need Android Studio for this route. A successful APK build has not been verified in this prepared source archive yet; if the workflow fails, open the run and share the error log so the project can be fixed.
