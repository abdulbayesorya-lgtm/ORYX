# Course Map

| Track | Target period | Focus |
|---|---|---|
| Computer and web foundations | Month 1 | Files, editor, browser, algorithms |
| HTML5 | Month 2 | Semantic structure, forms, media, accessibility |
| CSS3 + UI/UX | Month 3 | Layout, responsive design, usability |
| JavaScript | Months 4–5 | Language, DOM, storage, async, debugging |
| Git/GitHub | Month 6 | Version control and publishing |
| Node.js/Express | Months 7–8 | Backend, APIs, validation, security |
| SQL/databases | Months 9–10 | Data modeling, CRUD, relations, backup |
| React + capstone | Months 11–12 | Components, state, UI/UX, testing, project |

## Practice projects
1. Personal profile page
2. Responsive product page
3. Calculator
4. Quiz
5. Persistent to-do list
6. Admin dashboard
7. Products REST API
8. Student management system
9. Login/authentication prototype
10. Small online store
11. ORYA Academy enhancement project
12. Learner-selected capstone
