package com.orya.codeacademy

import android.content.*
import android.app.*
import android.os.Build
import java.util.*

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val p = context.getSharedPreferences("orya_schedule", Context.MODE_PRIVATE)
        val h = p.getInt("hour",17); val m = p.getInt("minute",0)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY,h); set(Calendar.MINUTE,m); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR,1)
        }
        val pi = PendingIntent.getBroadcast(context,100,Intent(context,AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi)
        else am.set(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi)
    }
}
