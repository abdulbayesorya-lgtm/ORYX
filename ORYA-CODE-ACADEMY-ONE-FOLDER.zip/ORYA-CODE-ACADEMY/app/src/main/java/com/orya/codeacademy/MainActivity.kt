package com.orya.codeacademy

import android.app.*
import android.content.*
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val gold = 0xFFD4AF37.toInt()
    private val black = 0xFF080808.toInt()
    private val prefs by lazy { getSharedPreferences("orya", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        showHome()
    }

    private fun requestNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 22)
            setBackgroundColor(black)
        }
        root.addView(label("ORYA CODE ACADEMY", 27, gold, true))
        root.addView(label("LEARN · CODE · BUILD", 14, 0xFFF5E6A8.toInt(), false))
        root.addView(label("یادگیری برنامه‌نویسی، قدم‌به‌قدم و آفلاین", 16, -1, false).apply { setPadding(0,18,0,18) })
        val quote = listOf(
            "هر روز یک قدم کوچک؛ هر ماه یک مهارت تازه.",
            "کد را فقط نخوان؛ اجرا کن، خراب کن، اصلاح کن.",
            "پیشرفت از تمرین منظم می‌آید، نه از عجله."
        ).random()
        root.addView(cardText("جملهٔ امروز", quote))
        root.addView(label("مسیر آموزشی ۱۲ ماهه", 20, gold, true).apply { setPadding(0,22,0,8) })
        val done = prefs.getInt("doneCount", 0)
        root.addView(label("پیشرفت درس‌ها: $done از ${Curriculum.courses.sumOf { it.lessons.size }} درس تکمیل شده", 14, -1, false))
        Curriculum.courses.forEachIndexed { i, course ->
            val b = Button(this).apply {
                text = "${course.title}\n${course.months}  •  ${course.lessons.size} درس"
                setTextColor(gold)
                setBackgroundColor(0xFF191919.toInt())
                isAllCaps = false
                setOnClickListener { startActivity(Intent(this@MainActivity, LessonActivity::class.java).putExtra("course", i)) }
            }
            root.addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        }
        val schedule = Button(this).apply {
            text = "برنامهٔ کلاس و زنگ یادآوری"
            isAllCaps = false
            setOnClickListener { startActivity(Intent(this@MainActivity, ScheduleActivity::class.java)) }
        }
        root.addView(schedule, LinearLayout.LayoutParams(-1,-2).apply { topMargin = 14 })
        root.addView(label("کارکرد آفلاین: درس‌ها و آزمون‌های داخل برنامه بدون اینترنت باز می‌شوند.", 12, 0xFFB7B7B7.toInt(), false).apply { setPadding(0,18,0,0) })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun label(s: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
    }
    private fun cardText(title: String, body: String) = TextView(this).apply {
        text = "$title\n$body"; textSize = 16f; setTextColor(-1); setPadding(16,16,16,16)
        setBackgroundColor(0xFF191919.toInt())
    }
}
