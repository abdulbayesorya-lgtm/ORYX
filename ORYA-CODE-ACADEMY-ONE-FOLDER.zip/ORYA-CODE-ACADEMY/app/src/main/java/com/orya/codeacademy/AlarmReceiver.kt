package com.orya.codeacademy

import android.app.*
import android.content.*
import android.os.Build
import java.util.*

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val channel = "orya_classes"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channel, "یادآوری کلاس", NotificationManager.IMPORTANCE_HIGH))
        }
        val open = PendingIntent.getActivity(context,0,Intent(context,MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context,channel) else Notification.Builder(context)
        n.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("وقت یادگیری ORYA CODE ACADEMY است!")
            .setContentText("کلاس خود را شروع کن. یک قدم امروز، مهارت فردا.")
            .setContentIntent(open).setAutoCancel(true)
        nm.notify(101,n.build())
        val p = context.getSharedPreferences("orya_schedule", Context.MODE_PRIVATE)
        if (p.getBoolean("daily",true)) {
            val h = p.getInt("hour",17); val m = p.getInt("minute",0)
            val cal = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR,1); set(Calendar.HOUR_OF_DAY,h); set(Calendar.MINUTE,m); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0)
            }
            val pi = PendingIntent.getBroadcast(context,100,Intent(context,AlarmReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi)
            else am.set(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi)
        }
    }
}
