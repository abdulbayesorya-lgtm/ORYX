package com.orya.codeacademy

import android.app.*
import android.content.*
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.widget.*
import java.util.*

class ScheduleActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("orya_schedule", MODE_PRIVATE) }
    private lateinit var hour: NumberPicker
    private lateinit var minute: NumberPicker
    private lateinit var duration: NumberPicker
    private lateinit var weekdays: CheckBox
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(22,24,22,24); setBackgroundColor(0xFF080808.toInt())
        }
        root.addView(TextView(this).apply { text="برنامهٔ کلاس"; textSize=26f; setTextColor(0xFFD4AF37.toInt()) })
        root.addView(TextView(this).apply { text="زمان شروع را تعیین کن؛ پایان کلاس بر اساس مدت محاسبه می‌شود."; textSize=15f; setTextColor(-1) })
        hour = picker(0,23,prefs.getInt("hour",17))
        minute = picker(0,59,prefs.getInt("minute",0))
        duration = picker(15,180,prefs.getInt("duration",60))
        root.addView(label("ساعت شروع"))
        root.addView(row(hour, minute))
        root.addView(label("مدت کلاس (دقیقه)"))
        root.addView(duration)
        weekdays = CheckBox(this).apply { text="یادآوری روزانه"; setTextColor(-1); isChecked=prefs.getBoolean("daily",true) }
        root.addView(weekdays)
        root.addView(Button(this).apply {
            text="ذخیره و فعال‌کردن زنگ"; isAllCaps=false
            setOnClickListener { saveAndSchedule() }
        })
        root.addView(TextView(this).apply {
            text="یادآوری به شکل اعلان اندروید است. برای اعلان دقیق ممکن است لازم باشد در تنظیمات گوشی اجازهٔ Alarms & reminders را بدهی."
            textSize=13f; setTextColor(0xFFBBBBBB.toInt()); setPadding(0,18,0,0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun picker(min:Int,max:Int,value:Int) = NumberPicker(this).apply { minValue=min; maxValue=max; this.value=value.coerceIn(min,max) }
    private fun label(s:String)=TextView(this).apply { text=s; textSize=16f; setTextColor(0xFFD4AF37.toInt()); setPadding(0,14,0,4) }
    private fun row(a:NumberPicker,b:NumberPicker)=LinearLayout(this).apply {
        orientation=LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0,180,1f)); addView(b,LinearLayout.LayoutParams(0,180,1f))
    }
    private fun saveAndSchedule() {
        prefs.edit().putInt("hour",hour.value).putInt("minute",minute.value)
            .putInt("duration",duration.value).putBoolean("daily",weekdays.isChecked).apply()
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            }
        }
        val intent = Intent(this, AlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(this, 100, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY,hour.value); set(Calendar.MINUTE,minute.value); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR,1)
        }
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 23 && (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi)
        } else {
            am.set(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi)
        }
        Toast.makeText(this,"کلاس ذخیره شد. شروع: %02d:%02d • پایان: %02d:%02d".format(hour.value,minute.value,(hour.value*60+minute.value+duration.value)/60%24,(hour.value*60+minute.value+duration.value)%60),Toast.LENGTH_LONG).show()
    }
}
