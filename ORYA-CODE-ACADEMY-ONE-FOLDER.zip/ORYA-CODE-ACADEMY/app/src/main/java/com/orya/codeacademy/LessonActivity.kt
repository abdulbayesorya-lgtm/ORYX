package com.orya.codeacademy

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.*
import android.content.Context

class LessonActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("orya", MODE_PRIVATE) }
    private var courseIndex = 0
    private var lessonIndex = 0
    private lateinit var root: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        courseIndex = intent.getIntExtra("course", 0).coerceIn(0, Curriculum.courses.lastIndex)
        showLesson()
    }
    private fun showLesson() {
        val course = Curriculum.courses[courseIndex]
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20,22,20,24); setBackgroundColor(0xFF080808.toInt())
        }
        root.addView(txt(course.title, 24, 0xFFD4AF37.toInt(), true))
        root.addView(txt("${course.months} • ${course.summary}", 14, 0xFFCCCCCC.toInt(), false))
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0,12,0,12) }
        course.lessons.forEachIndexed { i, lesson ->
            val b = Button(this).apply {
                text = "${i+1}. ${lesson.title} • ${lesson.duration} دقیقه"
                isAllCaps = false
                setOnClickListener { lessonIndex = i; showLessonDetail(courseIndex, i) }
            }
            content.addView(b, LinearLayout.LayoutParams(-1,-2).apply { topMargin = 5 })
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }
    private fun showLessonDetail(ci: Int, li: Int) {
        val course = Curriculum.courses[ci]
        val l = course.lessons[li]
        root.removeAllViews()
        root.addView(txt(l.title, 24, 0xFFD4AF37.toInt(), true))
        root.addView(txt("زمان پیشنهادی: ${l.duration} دقیقه", 14, 0xFFCCCCCC.toInt(), false))
        root.addView(txt("\nتوضیح درس\n${l.explanation}", 17, -1, false))
        root.addView(txt("\nنمونه\n${l.example}", 16, 0xFFF5E6A8.toInt(), false))
        root.addView(txt("\nتمرین عملی\n${l.task}", 17, -1, true))
        root.addView(txt("\nآزمون کوتاه\n${l.quiz}", 17, -1, true))
        val answer = EditText(this).apply { hint = "پاسخ خود را بنویس"; setTextColor(-1); setHintTextColor(0xFF999999.toInt()) }
        root.addView(answer)
        val check = Button(this).apply {
            text = "بررسی پاسخ"; isAllCaps = false
            setOnClickListener {
                val typed = answer.text.toString().trim()
                val correct = typed.equals(l.answer, true) ||
                    typed.contains(l.answer, true) || l.answer.contains(typed, true) && typed.length > 2
                AlertDialog.Builder(this@LessonActivity).setTitle(if(correct) "آفرین!" else "جواب نمونه")
                    .setMessage(if(correct) "پاسخ تو با جواب نمونه مطابقت دارد." else "جواب نمونه: ${l.answer}")
                    .setPositiveButton("ادامه") { _, _ ->
                        if (correct) {
                            val key = "done_${ci}_$li"
                            if (!prefs.getBoolean(key,false)) {
                                prefs.edit().putBoolean(key,true).putInt("doneCount", prefs.getInt("doneCount",0)+1).apply()
                            }
                        }
                    }.show()
            }
        }
        root.addView(check)
        root.addView(Button(this).apply { text = "بازگشت به فهرست درس‌ها"; isAllCaps = false; setOnClickListener { showLesson() } })
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun txt(s:String, size:Int, color:Int, bold:Boolean) = TextView(this).apply {
        text=s; textSize=size.toFloat(); setTextColor(color); setPadding(0,8,0,8)
        if(bold) setTypeface(null, Typeface.BOLD)
    }
}
